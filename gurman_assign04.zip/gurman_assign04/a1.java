package gurman_assign04;

import java.util.Scanner;

public class a1 {
	
	static int increment(float r) {
		
	int inc=0;
	if(r >=1 && r <= 4) {
			inc=10;
		}
		else if(r >= 4.1 && r <=7) {
			inc=25;
		}
		else {
			inc=30;
		}
	return inc;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s,inc=0;
		float r,ns;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the salary ");
        s = sc.nextInt();
        System.out.print("Enter the appraisal rating ");
        r = sc.nextFloat(); 
        
        inc=increment(r);
		
		ns=s+(s*inc/100);
		System.out.print(""+ns);
        
        sc.close();

	}

}
