package gurman_assign04;

import java.util.Scanner;

public class a4 {
	
	static void sum(int l,int u) {
		int sume=0,sumo=0,i,sum=0;
		
		if(l%2==0) {
			for(i=l;i<=u;i=i+2) {
				sume=sume+i;
				sumo=sumo+i+1;
				
			}
			if(i==u) {
				sumo=sumo-i-1;
				sum=sume-sumo;
			}
			else {
				sum=sumo-sume;
			}
		}
		else {
			for(i=l;i<=u;i=i+2) {
				sumo=sumo+i;
				sume=sume+i+1;
				
			}
			if(i==u) {
				sume=sume-i-1;
				sum=sumo-sume;
			}
			else {
				sum=sume-sumo;
			}
		}
		
		System.out.println("The sum of odd numbers from "+l+" to "+u+" is:"+sumo);
		System.out.println("The sum of even numbers from "+l+" to "+u+" is:"+sume);
		System.out.println("The absolute difference between the two sums is: "+sum);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int l,u;
		Scanner sc = new Scanner(System.in);
		System.out.print("lowerbound ");
        l = sc.nextInt();
        System.out.print("upperbound ");
        u = sc.nextInt();
        
        sum(l,u);
        
        sc.close();

	}

}
