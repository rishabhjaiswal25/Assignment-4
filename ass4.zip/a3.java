package ass4;

import java.util.Scanner;

public class Main {
	
	static void prime(int s,int e) {
		if(s>e)
			System.out.println("Provide valid input");
		
		for(int i=s;i<=e;i++) {
			int c=0;
			for(int j=2;j<=i;j++) {
				if(i%j==0)
					c++;
				
			}	
			if(c==1)
				System.out.print(i+" ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s,e;
		Scanner sc = new Scanner(System.in);
        s = sc.nextInt();
        e = sc.nextInt();
        
        prime(s,e);
        
        sc.close();

	}

}


