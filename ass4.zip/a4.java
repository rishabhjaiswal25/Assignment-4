package ass4;

import java.util.Scanner;

public class Main {
	
	static void sum(int l,int u) {
		int sume=0,sumo=0,i,sum=0;
		
		  
        for (i = 2; i <= u; i+=2) {  
            sume += i;  
        } 
        
        for(i = l; i <= u; i++){
            if((i%2) == 1){
                sumo += i;
            }
        }
        
			sum=sume-sumo;
		
		System.out.println("The sum of odd numbers from "+l+" to "+u+" is:"+sumo);
		System.out.println("The sum of even numbers from "+l+" to "+u+" is:"+sume);
		System.out.println("The absolute difference between the two sums is: "+sum);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int l,u;
		Scanner sc = new Scanner(System.in);
		System.out.print("lowerbound ");
        l = sc.nextInt();
        System.out.print("upperbound ");
        u = sc.nextInt();
        
        sum(l,u);
        
        sc.close();

	}

}

